/***************************************************************************
                          DIA_Busy.cpp  -  description
                             -------------------
    begin                : Thu Apr 21 2003
    copyright            : (C) 2003 by mean
    email                : fixounet@free.fr

	This function displays a busy box

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#include "config.h"


#include "ADM_default.h"



#include "DIA_busy.h"


void DIA_StartBusy( void )
{

}

void DIA_StopBusy( void )
{
}


void DIA_StartBusyDialog( void )
{
}

void DIA_StopBusyDialog( void )
{
}

void DIA_runBusy( void )
{
}
