#include <stdio.h>
#include "ADM_default.h"

uint8_t ADM_ocr_engine( void)
{
	return 0;
}
