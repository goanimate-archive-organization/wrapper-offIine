#include "ADM_inttype.h"

int DIA_colorSel(uint8_t *r, uint8_t *g, uint8_t *b) {return 0;}
