/**
    \file ADM_editInternal.h

*/