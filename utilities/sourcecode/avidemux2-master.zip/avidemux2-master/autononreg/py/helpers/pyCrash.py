testCrash()
