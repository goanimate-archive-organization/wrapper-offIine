gui=Gui()
red=gui.dirSelect("Select a directory ")
print(">>>>>>>>>>>>>>>>>>>>>>output"+red+".\n")
