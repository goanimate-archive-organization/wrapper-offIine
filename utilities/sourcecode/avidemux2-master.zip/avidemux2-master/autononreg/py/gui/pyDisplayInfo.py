gui=Gui()
gui.displayInfo("Hey","Hello World")
