adm=Avidemux()
editor=Editor()
for i in range(0,30):
        editor.printTiming(i)
print("Done . ")

