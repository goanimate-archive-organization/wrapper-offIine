//AD  <- 
/*
	Simple script that scans the orgDir directory
	and unpack all avi files
	The resuling file is put in destDir directory

	Using new directorySearch API

*/
var app = new Avidemux();
    	displayError("This is an ERROR");
	displayInfo("This is an INFO");
