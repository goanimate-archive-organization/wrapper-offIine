#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <inttypes.h>
#define ADM_assert(x) if(!(x)){printf("OOPs");}
#define LU "lu"
#define LLU "llu"
#define LD "ld"
#define LLD "lld"
#define LX "lx"
#define LLX "llx"
