Localizations on Mac has own names

Mac         Source
--------------------
English     en
el          gr
pt          PT-BR
pt-PT       pt
zh-Hans     zh-CN
zh-Hant     zh-TW